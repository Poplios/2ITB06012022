
import java.util.Scanner;

public class Benes {
    public static Scanner sc = new Scanner(System.in);
    public static int velikost = 0;
    public static int[] pole;

    public static void main(String[] args) {

        System.out.println("Velikost pole: ");
        pole = new int[sc.nextInt()];

        Napln();
        vypis();
    }

    public static void Napln() {
        for (int i = 0; i < pole.length; i++) {
            System.out.println("Velikost čísla: ");
            pole[i] = sc.nextInt();
        }

    }

    public static void Vyprint() {
        for (int i = 0; i < pole.length; i++) {
            System.out.print(pole[i] + " ");
        }

    }

    public static void vypis() {
        int scitac = 0;
        int scitac2 = 0;
        for (int i = 0; i < pole.length / 2; i++) {

            scitac = scitac + pole[i];

        }
        for (int j = pole.length / 2; j < pole.length; j++) {

            scitac2 = scitac2 + pole[j];

        }

        System.out.println(scitac2);

        if (scitac > scitac2) {
            System.out.println("levá stana je větší");
        } else {
            System.out.println("pravá stana je větší");
        }
   
           
            

    }

}